#ifndef SL_MATTER_OTA_CONFIG_H
#define SL_MATTER_OTA_CONFIG_H

// <<< Use Configuration Wizard in Context Menu >>>

// <o OTA_PERIODIC_TIMEOUT> OTA Requestor periodic timeout
// <d> Default: 86400
#define OTA_PERIODIC_TIMEOUT 86400

// <<< end of configuration section >>>

#endif // SL_MATTER_OTA_CONFIG_H
