# OpenThread Border Router

This is an OpenThread Border Router Project not intended to be compiled or flashed.

For more information on downloading and flashing the OpenThread Border Router image please follow the link to the 
[OpenThread Border Router Documentation](https://docs.silabs.com/matter/2.5.2/matter-thread/raspi-img)
    
    
