// DO NOT EDIT - Generated file
//
// Application configuration for AdministratorCommissioning based on EMBER configuration
// from inputs/large_lighting_app.matter
#pragma once

#include <app/util/cluster-config.h>
#include <clusters/AdministratorCommissioning/AttributeIds.h>
#include <clusters/AdministratorCommissioning/CommandIds.h>
#include <clusters/AdministratorCommissioning/Enums.h>

#include <array>

namespace chip {
namespace app {
namespace Clusters {
namespace AdministratorCommissioning {
namespace StaticApplicationConfig {
namespace detail {
inline constexpr AttributeId kEndpoint0EnabledAttributes[] = {
    Attributes::AcceptedCommandList::Id,
    Attributes::AdminFabricIndex::Id,
    Attributes::AdminVendorId::Id,
    Attributes::AttributeList::Id,
    Attributes::ClusterRevision::Id,
    Attributes::FeatureMap::Id,
    Attributes::GeneratedCommandList::Id,
    Attributes::WindowStatus::Id,
};

inline constexpr CommandId kEndpoint0EnabledCommands[] = {
    Commands::OpenCommissioningWindow::Id,
    Commands::RevokeCommissioning::Id,
};

} // namespace detail

using FeatureBitmapType = Feature;

inline constexpr std::array<Clusters::StaticApplicationConfig::ClusterConfiguration<FeatureBitmapType>, 1> kFixedClusterConfig = { {
    {
        .endpointNumber = 0,
        .featureMap = BitFlags<FeatureBitmapType> {
        },
        .enabledAttributes = Span<const AttributeId>(detail::kEndpoint0EnabledAttributes),
        .enabledCommands = Span<const CommandId>(detail::kEndpoint0EnabledCommands),
    },
} };

// If a specific attribute is supported at all across all endpoint static instantiations
inline constexpr bool IsAttributeEnabledOnSomeEndpoint(AttributeId attributeId) {
  switch (attributeId) {
    case Attributes::AcceptedCommandList::Id:
    case Attributes::AdminFabricIndex::Id:
    case Attributes::AdminVendorId::Id:
    case Attributes::AttributeList::Id:
    case Attributes::ClusterRevision::Id:
    case Attributes::FeatureMap::Id:
    case Attributes::GeneratedCommandList::Id:
    case Attributes::WindowStatus::Id:
      return true;
    default:
      return false;
  }
}

// If a specific command is supported at all across all endpoint static instantiations
inline constexpr bool IsCommandEnabledOnSomeEndpoint(CommandId commandId) {
  switch (commandId) {
    case Commands::OpenCommissioningWindow::Id:
    case Commands::RevokeCommissioning::Id:
      return true;
    default:
      return false;
  }
}

} // namespace StaticApplicationConfig
} // namespace AdministratorCommissioning
} // namespace Clusters
} // namespace app
} // namespace chip

