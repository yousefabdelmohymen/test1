
#ifndef MATTER_TRACING_BUILD_CONFIG_H_
#define MATTER_TRACING_BUILD_CONFIG_H_

// <<< Use Configuration Wizard in Context Menu >>>

// <q MATTER_TRACING_ENABLED> Matter Report on Entering Active
// <i> Default: 0
#define MATTER_TRACING_ENABLED 0

// <<< end of configuration section >>>

#endif // MATTER_TRACING_BUILD_CONFIG_H_
